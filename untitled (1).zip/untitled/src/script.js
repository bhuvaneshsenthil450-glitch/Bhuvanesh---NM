const bookingForm = document.getElementById('bookingForm');
const bookingList = document.getElementById('bookingList');

let bookings = [];

bookingForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const room = document.getElementById('room').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;

    const booking = {
        name,
        room,
        startDate,
        endDate
    };

    bookings.push(booking);
    displayBookings();
    bookingForm.reset();
});

function displayBookings() {
    bookingList.innerHTML = '';
    bookings.forEach((booking) => {
        const div = document.createElement('div');
        div.className = 'booking-card';
        div.innerHTML = `
            <strong>${booking.name}</strong> booked <em>${booking.room}</em><br>
            From: ${booking.startDate} To: ${booking.endDate}
        `;
        bookingList.appendChild(div);
    });
}